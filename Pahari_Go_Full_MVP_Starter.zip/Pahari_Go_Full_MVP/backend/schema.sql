-- Pahari Go starter marketplace schema for Supabase (PostgreSQL)
-- Run in Supabase SQL Editor. Review security policies before a public launch.
create extension if not exists pgcrypto;
create type public.app_role as enum ('customer','shopkeeper','delivery','admin');
create type public.order_status as enum ('placed','accepted','packed','picked_up','on_the_way','delivered','cancelled');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  phone text,
  role public.app_role not null default 'customer',
  created_at timestamptz not null default now()
);
create table public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id),
  name text not null,
  description text default '',
  address text not null,
  phone text,
  is_active boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  name text not null,
  description text default '',
  category text not null default 'General',
  price_paise integer not null check (price_paise >= 0),
  stock integer not null default 0 check (stock >= 0),
  image_url text,
  is_available boolean not null default true,
  created_at timestamptz not null default now()
);
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity unique,
  customer_id uuid not null references public.profiles(id),
  shop_id uuid not null references public.shops(id),
  delivery_partner_id uuid references public.profiles(id),
  status public.order_status not null default 'placed',
  subtotal_paise integer not null check (subtotal_paise >= 0),
  delivery_fee_paise integer not null default 0 check (delivery_fee_paise >= 0),
  platform_fee_paise integer not null default 0 check (platform_fee_paise >= 0),
  total_paise integer not null check (total_paise >= 0),
  payment_method text not null default 'cash_on_delivery' check (payment_method in ('cash_on_delivery','online')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  delivery_address text not null,
  notes text default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_name text not null,
  quantity integer not null check (quantity > 0),
  unit_price_paise integer not null check (unit_price_paise >= 0),
  line_total_paise integer not null check (line_total_paise >= 0)
);
create table public.platform_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.platform_settings(key,value) values
 ('launch_area', '{"name":"Bhaderwah","region":"Jammu and Kashmir"}'),
 ('fees', '{"shop_commission_percent":8,"customer_platform_fee_paise":500,"delivery_base_fee_paise":500}')
on conflict (key) do nothing;

alter table public.profiles enable row level security;
alter table public.shops enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.platform_settings enable row level security;

-- Profiles: user can read/update own basic profile. Role must be assigned server-side by an admin.
create policy "profile read own" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profile update own basic" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
-- Public can see active shops and available products; owners manage their own shops/products.
create policy "active shops visible" on public.shops for select using (is_active = true or owner_id = auth.uid());
create policy "shop owner creates shop" on public.shops for insert to authenticated with check (owner_id = auth.uid());
create policy "shop owner updates shop" on public.shops for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());
create policy "available products visible" on public.products for select using (is_available = true or exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
create policy "owner manages products" on public.products for all to authenticated using (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()) ) with check (exists (select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid()));
-- Orders need server-side validation before public production launch; customers see own, shop owners see shop orders, assigned partners see deliveries.
create policy "order participants read" on public.orders for select to authenticated using (
 customer_id = auth.uid() or delivery_partner_id = auth.uid() or exists(select 1 from public.shops s where s.id = shop_id and s.owner_id = auth.uid())
);
create policy "customer creates own order" on public.orders for insert to authenticated with check (customer_id = auth.uid());
create policy "order items participants read" on public.order_items for select to authenticated using (exists(select 1 from public.orders o where o.id = order_id and (o.customer_id = auth.uid() or o.delivery_partner_id = auth.uid() or exists(select 1 from public.shops s where s.id = o.shop_id and s.owner_id = auth.uid()))));
create policy "order items customer inserts" on public.order_items for insert to authenticated with check (exists(select 1 from public.orders o where o.id = order_id and o.customer_id = auth.uid()));
create policy "settings readable" on public.platform_settings for select using (true);

-- IMPORTANT: This is a starter schema, not a production-certified system. Do not expose service_role keys in the app.
-- Add server-side RPC/Edge Functions to validate totals, reserve stock, assign delivery partners, authorize role changes,
-- update order statuses, and process payment webhooks before taking real orders or money.
